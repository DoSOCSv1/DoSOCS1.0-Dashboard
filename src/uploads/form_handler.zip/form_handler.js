function processForm(LOCA, Method){	

   try
   { 
	   

   	if( $("form").ricolaValidateForm() )
	{
   		
   		if((typeof LOCA == 'undefined' || LOCA == '') && typeof formHandler != 'undefined')
		{
   	       LOCA = formHandler['action_url'];
   		}
   
   		if(typeof LOCA == 'undefined' || LOCA == '')
		{
   		       LOCA = $("form").attr("action");
   		}

   		$("input").ricolaInputHintClear();//for 2.3
   		$(":input").ricolaInputHintClear();//for 2.4+
   
      	Ricola.page.showPleaseWait();
      	$(".ricValidate").ricolaValidateClearError();
      	      	
      	$("#errorDiv").hide();
   
   		var data = $("form").serialize();		
        if(typeof Method != 'undefined' && Method != '')
		{
       	   data = 'Method=' + Method + '&' + data; 			
        } 

   		$.ajax({
   		   type: "POST",
   		   url: LOCA,
   		   data: data,
   		   dataType: "json",
   		   cache: false,
   		   success: function(response)
		   {	
               jQuery.each(response, function(k, v)
			   {  
                  if (k.toLowerCase() == 'errors')
				  {
                     msg = "";
                     jQuery.each(v, function(i, val)
					 {
                        msg += val + "\n";
                     });  
                     DisplayDivErrorMsg(msg);
                     Ricola.page.hidePleaseWait();
                  } 
				  else if (k == 'info')
				  {
                     jQuery.each(v, function(i, val)
					 {                 	 
                        if(i == 'success')
						{
							DisplayDivSuccessMsg(val);
							Ricola.page.hidePleaseWait();
							window.setTimeout(function(){window.close();},2500);
							
						}
                     });
                  }  
                  else if (k.toLowerCase() == 'js_func')
				  {                   	  
					jQuery.each(v, function(i, val)
					{
						eval( val );
					});
                  }          
               }); 
   		  },
   		  error: function(XMLHttpRequest, textStatus, errorThrown)
		  {		  
			Ricola.page.hidePleaseWait();

   		  	if( LoginRequired(XMLHttpRequest.responseText) )
			{
   		  		  DisplayDivErrorMsg("You are no longer authenticated.  Please login again by refreshing this page.");	  	  	
   		  	}
   		  	else
			{		  		 
   		  		  DisplayDivErrorMsg("An error occurred, please try again later." + XMLHttpRequest.responseText);
   		  	}	   		     
   		  }
   		});
   	}
	
	}
	catch(e){
	   DisplayDivErrorMsg('An application error has occurred.<br>An BCS administrator has been notifed.\n');
	   NotifyAdmin(e.description);
	}
}

function DisplayDivErrorMsg(ErrorMsg)
{	
	if(ErrorMsg != ''){
	    $("#errorMsg").html("");   
	    errors = ErrorMsg.split('\n');
 
	    for(i=0; i < errors.length; i++){
	    	   
	       if( errors[i] != ''){
	    	  if(errors.length > 2){
	    		  $("#errorMsg").append("<li>" + errors[i] + "</li>");
	    	  } 
	    	  else{
	    		  $("#errorMsg").append(errors[i]);  
	    	  }	          
	       }
	      }
     
	    $("#errorMsg").wrapInner("<ul style='list-style-type: square;'></ul>");    
	    $("#errorDiv").show();	    
	    location.hash= '#ErrorAnchor';    	  
	}

	if( ErrorMsg.toLowerCase().indexOf('BCS administrator') > 0 )
	{
		NotifyAdmin(ErrorMsg);	
	}
}

function DisplayDivSuccessMsg(SuccessMsg)
{	
	if(SuccessMsg != ''){
	    $("#successMsg").html("");   
	    rows = SuccessMsg.split('\n');
 
	    for(i=0; i < rows.length; i++){
	    	   
	       if( rows[i] != ''){
	    	  if(rows.length > 2){
	    		  $("#successMsg").append("<li>" + rows[i] + "</li>");
	    	  } 
	    	  else{
	    		  $("#successMsg").append(rows[i]);  
	    	  }	          
	       }
	      }
     
	    $("#successMsg").wrapInner("<ul style='list-style-type: square;'></ul>");    
	    $("#successDiv").show();	    
	    location.hash= '#SuccessAnchor';    	  
	}
}

function LoginRequired(Content){
	rtrn = false;
	if( Content.indexOf('Login Page') > 0 || Content.indexOf('/admin/login.fcc') > 0 ){
		rtrn = true;
	}
	return rtrn;
}